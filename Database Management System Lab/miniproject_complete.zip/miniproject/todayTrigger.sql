CREATE OR REPLACE TRIGGER PreventFutureCrimeEntry
BEFORE INSERT OR UPDATE ON crime
FOR EACH ROW
BEGIN
    -- Check if the entry date is set to a future date
    IF :NEW.entry_date > SYSDATE THEN
        -- Prevent the insertion or update and raise an error
        RAISE_APPLICATION_ERROR(-20004, 'Crime entry date cannot be set to a future date.');
    END IF;
END;
/
