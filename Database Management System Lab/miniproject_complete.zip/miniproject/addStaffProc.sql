CREATE OR REPLACE PROCEDURE InsertStaffMember(
    p_staffid IN NUMBER,
    p_name IN VARCHAR2,
    p_role IN VARCHAR2
) AS
BEGIN
    INSERT INTO staff (staffid, name, role) VALUES (p_staffid, p_name, p_role);
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Staff member inserted successfully.');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error inserting staff member: ' || SQLERRM);
END InsertStaffMember;
/
