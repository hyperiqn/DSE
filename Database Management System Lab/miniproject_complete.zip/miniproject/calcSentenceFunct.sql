CREATE OR REPLACE FUNCTION CalculatePrisonerSentenceEnd(p_pid IN prisoner.pid%TYPE)
RETURN DATE IS
    v_release_date DATE;
BEGIN
    SELECT entry_date + sentence_length * 30 INTO v_release_date
    FROM prisoner INNER JOIN crime ON prisoner.crimeid = crime.crimeid
    WHERE pid = p_pid;
    
    RETURN v_release_date;
END;
/