CREATE OR REPLACE FUNCTION IsCellOccupied(cellId VARCHAR2)
RETURN NUMBER IS
  isOccupied NUMBER := 0; -- Initialize as 0 (FALSE)
BEGIN
  SELECT COUNT(*)
  INTO isOccupied
  FROM prisoner
  WHERE cellid = cellId;

  RETURN isOccupied;
END IsCellOccupied;
/
