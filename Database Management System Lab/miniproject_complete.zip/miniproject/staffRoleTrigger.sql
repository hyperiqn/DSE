CREATE OR REPLACE TRIGGER ValidateStaffRoleChange
BEFORE UPDATE OF role ON staff
FOR EACH ROW
DECLARE
    v_invalid_role BOOLEAN := TRUE;
BEGIN
    IF :NEW.role IN ('chef', 'cleaner', 'guard') THEN
        v_invalid_role := FALSE;
    END IF;

    IF v_invalid_role THEN
        RAISE_APPLICATION_ERROR(-20002, 'Attempt to set an invalid role. Valid roles are chef, cleaner, and guard.');
    END IF;
END;
/