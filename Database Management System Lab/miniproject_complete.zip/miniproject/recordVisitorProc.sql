CREATE OR REPLACE PROCEDURE RecordVisitorEntry(
    p_pid IN NUMBER,
    p_visitor_name IN VARCHAR2,
    p_visit_date IN DATE
) AS
BEGIN
    INSERT INTO visitor (pid, name, visit_date)
    VALUES (p_pid, p_visitor_name, p_visit_date);
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Visitor entry recorded successfully.');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error recording visitor entry: ' || SQLERRM);
END RecordVisitorEntry;
/
